# AluraFlix - Clase 03

A Pen created on CodePen.io. Original URL: [https://codepen.io/Flory-Arias-Hernandez/pen/ZEwGVaR](https://codepen.io/Flory-Arias-Hernandez/pen/ZEwGVaR).

