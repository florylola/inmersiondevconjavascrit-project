var listMisPelis = [
  "https://i.blogs.es/59c352/cazadores-20de-20sombras-20mortal-20instruments-20city-20of-20bones-20la-20pelicula/650_1200.jpg",

  "https://pics.filmaffinity.com/avatar_the_way_of_water-722646748-mmed.jpg",

  "https://pics.filmaffinity.com/Tren_a_Busan-266744354-mmed.jpg",
  "https://pics.filmaffinity.com/Blancanieves_y_la_leyenda_del_cazador-111851943-large.jpg",
  "https://mx.web.img3.acsta.net/pictures/19/02/16/18/18/5935264.jpg"
];

listMisPelis.push(
  "https://i.pinimg.com/1200x/70/a3/bd/70a3bda637b71ae01aaff6d5054113d4.jpg"
);
var nameList = [
  "Cazadores de sombras",

  "Avatar the Way of Water",

  "Tren a Busan",

  "Blancanieves y la Leyenda del cazador",

  "El dia despúes de mañana"
];

document.write('<div class= "container_todosFilmes" >');

var i = 0;
while (i < listMisPelis.length) {
  if (listMisPelis[i].endsWith("jpg") || listMisPelis[i].endsWith("jpeg")) {
    document.write('<div class= "container_filme" >');
    document.write("<img src=" + listMisPelis[i] + " > ");
    document.write("<p>" + nameList[i] + "/<p>");
    document.write("</div>");
  } else {
    document.write(
      "<p> La imagen " +
        i +
        "no se leyo porque no es un archivo jpeg o jpg </p>"
    );
  }
  i++;
}
document.write("</div>");
